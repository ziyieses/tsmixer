# coding=utf-8
# Copyright 2023 The Google Research Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Implementation of fully-connected linear model for forecasting."""

import tensorflow as tf


class Model(tf.keras.Model):
  """Fully linear model."""

  def __init__(self, n_channel, pred_len):
    super().__init__()
    self.flatten = tf.keras.layers.Flatten()
    self.dense = tf.keras.layers.Dense(pred_len * n_channel)
    self.reshape = tf.keras.layers.Reshape((pred_len, n_channel))

  def call(self, x):
    # x: [Batch, Input length, Channel]
    x = self.flatten(x)
    x = self.dense(x)
    x = self.reshape(x)
    return x  # [Batch, Output length, Channel]
